
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.0'
version = '1.15.0'
full_version = '1.15.0'
git_revision = 'ccfbcc1cd9a4035a467f2e982a565ab27de25b6b'
release = True

if not release:
    version = full_version
